import { users, notes, visitors, type User, type InsertUser, type Note, type InsertNote, type Visitor, type InsertVisitor } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Notes CRUD
  getAllNotes(): Promise<Note[]>;
  getNote(id: number): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: number, note: Partial<InsertNote>): Promise<Note | undefined>;
  deleteNote(id: number): Promise<boolean>;
  searchNotes(query: string): Promise<Note[]>;
  
  // Visitor tracking
  logVisitor(visitor: InsertVisitor): Promise<Visitor>;
  getAllVisitors(): Promise<Visitor[]>;
  getVisitorStats(): Promise<{
    totalVisits: number;
    uniqueIPs: number;
    todayVisits: number;
    topPages: Array<{ path: string; count: number }>;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private notes: Map<number, Note>;
  private visitors: Visitor[];
  private currentUserId: number;
  private currentNoteId: number;
  private currentVisitorId: number;

  constructor() {
    this.users = new Map();
    this.notes = new Map();
    this.visitors = [];
    this.currentUserId = 1;
    this.currentNoteId = 1;
    this.currentVisitorId = 1;
    
    // Initialize with some sample notes for demo
    this.initializeSampleNotes();
  }

  private initializeSampleNotes() {
    const sampleNotes = [
      {
        title: "Meeting Notes - Q4 Planning",
        content: `<h2>Q4 Planning Meeting - October 15, 2024</h2>
        
<h3>Attendees:</h3>
<ul>
<li>Sarah Johnson (Project Manager)</li>
<li>Mike Chen (Lead Developer)</li>
<li>Emma Rodriguez (UX Designer)</li>
<li>David Kim (Marketing Lead)</li>
</ul>

<h3>Key Discussion Points:</h3>
<ol>
<li><strong>Budget Allocation:</strong> Approved 30% increase for development tools and infrastructure</li>
<li><strong>Team Expansion:</strong> Planning to hire 2 additional developers and 1 QA engineer</li>
<li><strong>Product Roadmap:</strong> Finalized features for Q4 release including mobile app optimization</li>
<li><strong>Marketing Strategy:</strong> Launch campaign scheduled for December 1st</li>
</ol>

<h3>Action Items:</h3>
<ul>
<li>Sarah: Finalize hiring timeline by October 20th</li>
<li>Mike: Review technical specifications for new features</li>
<li>Emma: Complete user testing for mobile interface</li>
<li>David: Prepare marketing materials and campaign assets</li>
</ul>

<h3>Next Meeting:</h3>
<p>October 29, 2024 at 2:00 PM - Conference Room B</p>`,
        category: "work",
        isFavorite: false,
      },
      {
        title: "Project Ideas",
        content: `<h2>Innovative Project Ideas</h2>
<ol>
<li><strong>Mobile app for habit tracking</strong> - AI-powered suggestions</li>
<li><strong>Recipe sharing platform</strong> - Community-driven with ratings</li>
<li><strong>Virtual study groups</strong> - Video collaboration tools</li>
<li><strong>Fitness challenge app</strong> - Social motivation features</li>
</ol>`,
        category: "personal",
        isFavorite: true,
      },
      {
        title: "Recipe Collection",
        content: `<h2>Grandmother's Apple Pie Recipe</h2>
<h3>Ingredients:</h3>
<ul>
<li>6-8 Granny Smith apples</li>
<li>1 cup granulated sugar</li>
<li>2 tablespoons flour</li>
<li>1 teaspoon cinnamon</li>
<li>1/4 teaspoon nutmeg</li>
<li>2 pie crusts</li>
</ul>

<h3>Instructions:</h3>
<ol>
<li>Preheat oven to 425°F</li>
<li>Peel and slice apples</li>
<li>Mix sugar, flour, and spices</li>
<li>Combine with apples and place in pie crust</li>
<li>Cover with top crust and bake for 45 minutes</li>
</ol>`,
        category: "personal",
        isFavorite: false,
      },
    ];

    sampleNotes.forEach(note => {
      const fullNote: Note = {
        ...note,
        id: this.currentNoteId++,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.notes.set(fullNote.id, fullNote);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllNotes(): Promise<Note[]> {
    return Array.from(this.notes.values()).sort((a, b) => {
      const aTime = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
      const bTime = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
      return bTime - aTime;
    });
  }

  async getNote(id: number): Promise<Note | undefined> {
    return this.notes.get(id);
  }

  async createNote(note: InsertNote): Promise<Note> {
    const id = this.currentNoteId++;
    const now = new Date();
    const fullNote: Note = { 
      ...note, 
      id, 
      category: note.category || "personal",
      isFavorite: note.isFavorite || false,
      createdAt: now, 
      updatedAt: now 
    };
    this.notes.set(id, fullNote);
    return fullNote;
  }

  async updateNote(id: number, noteUpdate: Partial<InsertNote>): Promise<Note | undefined> {
    const existingNote = this.notes.get(id);
    if (!existingNote) return undefined;

    const updatedNote: Note = {
      ...existingNote,
      ...noteUpdate,
      updatedAt: new Date(),
    };
    this.notes.set(id, updatedNote);
    return updatedNote;
  }

  async deleteNote(id: number): Promise<boolean> {
    return this.notes.delete(id);
  }

  async searchNotes(query: string): Promise<Note[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.notes.values()).filter(note => 
      note.title.toLowerCase().includes(lowercaseQuery) ||
      note.content.toLowerCase().includes(lowercaseQuery)
    );
  }

  async logVisitor(visitor: InsertVisitor): Promise<Visitor> {
    const id = this.currentVisitorId++;
    const fullVisitor: Visitor = {
      ...visitor,
      id,
      userAgent: visitor.userAgent || null,
      referer: visitor.referer || null,
      sessionId: visitor.sessionId || null,
      timestamp: new Date(),
    };
    this.visitors.push(fullVisitor);
    return fullVisitor;
  }

  async getAllVisitors(): Promise<Visitor[]> {
    return this.visitors.sort((a, b) => {
      const aTime = a.timestamp ? new Date(a.timestamp).getTime() : 0;
      const bTime = b.timestamp ? new Date(b.timestamp).getTime() : 0;
      return bTime - aTime;
    });
  }

  async getVisitorStats(): Promise<{
    totalVisits: number;
    uniqueIPs: number;
    todayVisits: number;
    topPages: Array<{ path: string; count: number }>;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayVisits = this.visitors.filter(v => 
      v.timestamp && new Date(v.timestamp) >= today
    ).length;

    const uniqueIPs = new Set(this.visitors.map(v => v.ipAddress)).size;

    const pathCounts = this.visitors.reduce((acc, visitor) => {
      acc[visitor.path] = (acc[visitor.path] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topPages = Object.entries(pathCounts)
      .map(([path, count]) => ({ path, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    return {
      totalVisits: this.visitors.length,
      uniqueIPs,
      todayVisits,
      topPages,
    };
  }
}

export const storage = new MemStorage();
