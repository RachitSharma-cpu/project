import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Activity, Users, Eye, TrendingUp } from "lucide-react";
import type { Visitor } from "@shared/schema";

interface VisitorStats {
  totalVisits: number;
  uniqueIPs: number;
  todayVisits: number;
  topPages: Array<{ path: string; count: number }>;
}

export default function Admin() {
  const { data: visitors, isLoading: visitorsLoading } = useQuery<Visitor[]>({
    queryKey: ['/api/secret-admin-analytics/visitors'],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<VisitorStats>({
    queryKey: ['/api/secret-admin-analytics/stats'],
  });

  const formatTimestamp = (timestamp: Date) => {
    return new Date(timestamp).toLocaleString();
  };

  const getLocationFromIP = (ip: string) => {
    // In a real app, you might use a geolocation service
    if (ip.startsWith('192.168') || ip.startsWith('10.') || ip.startsWith('172.')) {
      return "Local Network";
    }
    return "Unknown Location";
  };

  const getBrowserFromUserAgent = (userAgent: string | null) => {
    if (!userAgent) return "Unknown";
    if (userAgent.includes('Chrome')) return "Chrome";
    if (userAgent.includes('Firefox')) return "Firefox";
    if (userAgent.includes('Safari')) return "Safari";
    if (userAgent.includes('Edge')) return "Edge";
    return "Other";
  };

  const isLoading = visitorsLoading || statsLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">🕵️ Secret Analytics Dashboard</h1>
          <p className="text-gray-600">Hidden visitor tracking and analytics</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Visits</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalVisits || 0}</div>
              <p className="text-xs text-muted-foreground">All time visits</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Unique Visitors</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.uniqueIPs || 0}</div>
              <p className="text-xs text-muted-foreground">Unique IP addresses</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Visits</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.todayVisits || 0}</div>
              <p className="text-xs text-muted-foreground">Visits today</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Top Page</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.topPages?.[0]?.count || 0}</div>
              <p className="text-xs text-muted-foreground">{stats?.topPages?.[0]?.path || "No data"}</p>
            </CardContent>
          </Card>
        </div>

        {/* Top Pages */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Most Visited Pages</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats?.topPages?.slice(0, 5).map((page, index) => (
                  <div key={page.path} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="w-6 h-6 rounded-full p-0 flex items-center justify-center text-xs">
                        {index + 1}
                      </Badge>
                      <span className="font-medium">{page.path}</span>
                    </div>
                    <Badge>{page.count} visits</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Browser Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {visitors && (() => {
                  const browserCounts = visitors.reduce((acc, visitor) => {
                    const browser = getBrowserFromUserAgent(visitor.userAgent);
                    acc[browser] = (acc[browser] || 0) + 1;
                    return acc;
                  }, {} as Record<string, number>);

                  return Object.entries(browserCounts)
                    .sort(([,a], [,b]) => b - a)
                    .slice(0, 5)
                    .map(([browser, count], index) => (
                      <div key={browser} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="w-6 h-6 rounded-full p-0 flex items-center justify-center text-xs">
                            {index + 1}
                          </Badge>
                          <span className="font-medium">{browser}</span>
                        </div>
                        <Badge>{count} visits</Badge>
                      </div>
                    ));
                })()}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Visitors Table */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Visitors</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>IP Address</TableHead>
                  <TableHead>Page</TableHead>
                  <TableHead>Browser</TableHead>
                  <TableHead>Referer</TableHead>
                  <TableHead>Location</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visitors?.slice(0, 50).map((visitor) => (
                  <TableRow key={visitor.id}>
                    <TableCell className="font-mono text-sm">
                      {formatTimestamp(visitor.timestamp)}
                    </TableCell>
                    <TableCell className="font-mono">
                      {visitor.ipAddress}
                    </TableCell>
                    <TableCell className="font-medium">
                      {visitor.path}
                    </TableCell>
                    <TableCell>
                      {getBrowserFromUserAgent(visitor.userAgent)}
                    </TableCell>
                    <TableCell className="max-w-xs truncate">
                      {visitor.referer || "Direct"}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">
                        {getLocationFromIP(visitor.ipAddress)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
