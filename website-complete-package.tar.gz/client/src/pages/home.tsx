import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Star, Briefcase, Home as HomeIcon, Inbox, Save, Paperclip, Share, Bold, Italic, Underline, List, ListOrdered } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useNotes } from "@/hooks/use-notes";
import RichTextEditor from "@/components/rich-text-editor";
import NoteSidebar from "@/components/note-sidebar";
import type { Note } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedNoteId, setSelectedNoteId] = useState<number | null>(null);
  const [noteTitle, setNoteTitle] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [showNewNote, setShowNewNote] = useState(false);

  const { notes, createNote, updateNote, deleteNote, searchNotes, isLoading } = useNotes();

  const selectedNote = notes?.find(note => note.id === selectedNoteId);

  // Filter notes based on category
  const filteredNotes = notes?.filter(note => {
    if (selectedCategory === "all") return true;
    if (selectedCategory === "favorites") return note.isFavorite;
    return note.category === selectedCategory;
  }) || [];

  // Search functionality
  const searchResults = useQuery({
    queryKey: ['/api/notes/search', searchQuery],
    queryFn: () => searchNotes(searchQuery),
    enabled: searchQuery.length > 0,
  });

  const displayNotes = searchQuery ? (searchResults.data || []) : filteredNotes;

  useEffect(() => {
    if (selectedNote) {
      setNoteTitle(selectedNote.title);
      setNoteContent(selectedNote.content);
      setShowNewNote(false);
    }
  }, [selectedNote]);

  const handleCreateNote = async () => {
    if (!noteTitle.trim()) return;
    
    const newNote = await createNote({
      title: noteTitle,
      content: noteContent,
      category: "personal",
      isFavorite: false,
    });
    
    setSelectedNoteId(newNote.id);
    setShowNewNote(false);
  };

  const handleUpdateNote = async () => {
    if (!selectedNoteId || !noteTitle.trim()) return;
    
    await updateNote(selectedNoteId, {
      title: noteTitle,
      content: noteContent,
    });
  };

  const handleNewNote = () => {
    setSelectedNoteId(null);
    setNoteTitle("");
    setNoteContent("");
    setShowNewNote(true);
  };

  const handleSelectNote = (note: Note) => {
    setSelectedNoteId(note.id);
  };

  const toggleFavorite = async () => {
    if (!selectedNoteId || !selectedNote) return;
    
    await updateNote(selectedNoteId, {
      isFavorite: !selectedNote.isFavorite,
    });
  };

  const formatRelativeTime = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  const getWordCount = (content: string) => {
    const text = content.replace(/<[^>]*>/g, '');
    return text.trim().split(/\s+/).length;
  };

  const getCharCount = (content: string) => {
    return content.replace(/<[^>]*>/g, '').length;
  };

  const getReadTime = (content: string) => {
    const words = getWordCount(content);
    return Math.max(1, Math.ceil(words / 200));
  };

  const categoryCounts = {
    all: notes?.length || 0,
    favorites: notes?.filter(n => n.isFavorite).length || 0,
    work: notes?.filter(n => n.category === "work").length || 0,
    personal: notes?.filter(n => n.category === "personal").length || 0,
  };

  return (
    <div className="min-h-screen bg-gray-50 font-inter">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 fixed top-0 left-0 right-0 z-10">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="text-primary text-2xl">📝</div>
              <h1 className="text-2xl font-bold text-gray-900">NotePad Pro</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search notes..."
                className="w-80 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face" 
                alt="User profile" 
                className="w-10 h-10 rounded-full"
              />
              <span className="text-gray-700 font-medium">John Doe</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-screen pt-16">
        {/* Sidebar */}
        <NoteSidebar
          notes={displayNotes}
          selectedNoteId={selectedNoteId}
          selectedCategory={selectedCategory}
          categoryCounts={categoryCounts}
          onSelectNote={handleSelectNote}
          onSelectCategory={setSelectedCategory}
          onNewNote={handleNewNote}
          onDeleteNote={deleteNote}
          formatRelativeTime={formatRelativeTime}
          isLoading={isLoading}
        />

        {/* Main Editor */}
        <main className="flex-1 flex flex-col bg-white">
          {/* Editor Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
            <div className="flex items-center space-x-4">
              <Input
                type="text"
                className="text-2xl font-bold border-none outline-none focus:ring-0 p-0 bg-transparent text-gray-900"
                placeholder="Untitled Note"
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
              />
            </div>
            
            <div className="flex items-center space-x-3">
              {/* Action Buttons */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleFavorite}
                className={`p-2 hover:bg-yellow-50 ${selectedNote?.isFavorite ? 'text-yellow-500' : 'text-gray-600 hover:text-yellow-500'}`}
                disabled={!selectedNoteId}
              >
                <Star className="h-4 w-4" />
              </Button>
              
              <Button variant="ghost" size="sm" className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100">
                <Paperclip className="h-4 w-4" />
              </Button>
              
              <Button variant="ghost" size="sm" className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100">
                <Share className="h-4 w-4" />
              </Button>
              
              <Button 
                onClick={showNewNote ? handleCreateNote : handleUpdateNote}
                className="bg-accent text-white px-4 py-2 rounded-lg font-medium hover:bg-emerald-600 transition-colors"
                disabled={!noteTitle.trim()}
              >
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
            </div>
          </div>

          {/* Rich Text Editor */}
          <div className="flex-1 p-6">
            <div className="h-full border border-gray-200 rounded-lg overflow-hidden">
              <RichTextEditor
                content={noteContent}
                onChange={setNoteContent}
                placeholder="Start writing your note..."
              />
            </div>
          </div>

          {/* Status Bar */}
          <div className="flex items-center justify-between px-6 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
            <div className="flex items-center space-x-4">
              <span>{getWordCount(noteContent)} words</span>
              <span>{getCharCount(noteContent)} characters</span>
              <span>~{getReadTime(noteContent)} min read</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span>Auto-saved</span>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
