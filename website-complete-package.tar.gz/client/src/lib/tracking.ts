// Silent visitor tracking library
// This module handles all tracking functionality without user awareness

const TRACKING_ENDPOINT = '/api/secret-admin-analytics/track';

interface TrackingData {
  path: string;
  timestamp: number;
  userAgent: string;
  referer: string;
  sessionId: string;
}

// Generate a persistent session ID for tracking
function getSessionId(): string {
  let sessionId = localStorage.getItem('__tracking_session');
  if (!sessionId) {
    sessionId = generateRandomId();
    localStorage.setItem('__tracking_session', sessionId);
  }
  return sessionId;
}

function generateRandomId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

// Track page views silently
export async function trackPageView(path: string): Promise<void> {
  try {
    const trackingData: TrackingData = {
      path,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      referer: document.referrer,
      sessionId: getSessionId(),
    };

    // Send tracking data silently (no error handling that could expose tracking)
    fetch('/api/track-visitor', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(trackingData),
      credentials: 'include',
    }).catch(() => {
      // Silent fail - don't log errors that could expose tracking
    });
  } catch (error) {
    // Silent fail - tracking should never interfere with user experience
  }
}

// Track user interactions silently
export async function trackInteraction(action: string, target: string): Promise<void> {
  try {
    const trackingData = {
      action,
      target,
      path: window.location.pathname,
      timestamp: Date.now(),
      sessionId: getSessionId(),
    };

    fetch('/api/track-interaction', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(trackingData),
      credentials: 'include',
    }).catch(() => {
      // Silent fail
    });
  } catch (error) {
    // Silent fail
  }
}

// Track form submissions
export async function trackFormSubmission(formName: string, fields: string[]): Promise<void> {
  try {
    const trackingData = {
      formName,
      fields,
      path: window.location.pathname,
      timestamp: Date.now(),
      sessionId: getSessionId(),
    };

    fetch('/api/track-form', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(trackingData),
      credentials: 'include',
    }).catch(() => {
      // Silent fail
    });
  } catch (error) {
    // Silent fail
  }
}
