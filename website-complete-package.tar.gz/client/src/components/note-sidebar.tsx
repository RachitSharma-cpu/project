import { Plus, Inbox, Star, Briefcase, Home, Search, MoreVertical, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import type { Note } from "@shared/schema";

interface NoteSidebarProps {
  notes: Note[];
  selectedNoteId: number | null;
  selectedCategory: string;
  categoryCounts: {
    all: number;
    favorites: number;
    work: number;
    personal: number;
  };
  onSelectNote: (note: Note) => void;
  onSelectCategory: (category: string) => void;
  onNewNote: () => void;
  onDeleteNote: (id: number) => void;
  formatRelativeTime: (date: Date) => string;
  isLoading: boolean;
}

export default function NoteSidebar({
  notes,
  selectedNoteId,
  selectedCategory,
  categoryCounts,
  onSelectNote,
  onSelectCategory,
  onNewNote,
  onDeleteNote,
  formatRelativeTime,
  isLoading,
}: NoteSidebarProps) {
  const categories = [
    { id: "all", label: "All Notes", icon: Inbox, count: categoryCounts.all },
    { id: "favorites", label: "Favorites", icon: Star, count: categoryCounts.favorites },
    { id: "work", label: "Work", icon: Briefcase, count: categoryCounts.work },
    { id: "personal", label: "Personal", icon: Home, count: categoryCounts.personal },
  ];

  const getPreview = (content: string) => {
    const text = content.replace(/<[^>]*>/g, '');
    return text.substring(0, 100) + (text.length > 100 ? '...' : '');
  };

  const hasAttachments = (content: string) => {
    return content.includes('<img') || content.includes('href=');
  };

  if (isLoading) {
    return (
      <aside className="w-80 bg-white shadow-sm border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <Skeleton className="h-12 w-full" />
        </div>
        <div className="p-4 border-b border-gray-200">
          <Skeleton className="h-6 w-24 mb-3" />
          <div className="space-y-2">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        </div>
        <div className="flex-1 p-4">
          <Skeleton className="h-6 w-32 mb-3" />
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-80 bg-white shadow-sm border-r border-gray-200 flex flex-col">
      {/* New Note Button */}
      <div className="p-4 border-b border-gray-200">
        <Button 
          onClick={onNewNote}
          className="w-full bg-primary text-white py-3 px-4 rounded-lg font-medium hover:bg-indigo-700 transition-colors flex items-center justify-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>New Note</span>
        </Button>
      </div>

      {/* Categories */}
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Categories</h3>
        <nav className="space-y-1">
          {categories.map((category) => {
            const Icon = category.icon;
            const isActive = selectedCategory === category.id;
            
            return (
              <button
                key={category.id}
                onClick={() => onSelectCategory(category.id)}
                className={`w-full flex items-center px-3 py-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors ${
                  isActive ? 'bg-gray-100' : ''
                }`}
              >
                <Icon className={`w-5 h-5 mr-3 ${
                  category.id === 'favorites' ? 'text-yellow-400' :
                  category.id === 'work' ? 'text-blue-400' :
                  category.id === 'personal' ? 'text-green-400' :
                  'text-gray-400'
                }`} />
                <span>{category.label}</span>
                <Badge variant="secondary" className="ml-auto">
                  {category.count}
                </Badge>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Recent Notes List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
            {selectedCategory === 'all' ? 'Recent Notes' : 
             selectedCategory === 'favorites' ? 'Favorite Notes' :
             selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1) + ' Notes'}
          </h3>
          
          <div className="space-y-2">
            {notes.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Search className="h-8 w-8 mx-auto mb-2" />
                <p>No notes found</p>
              </div>
            ) : (
              notes.map((note) => (
                <div
                  key={note.id}
                  className={`relative group p-3 border border-gray-200 rounded-lg hover:border-primary cursor-pointer transition-colors ${
                    selectedNoteId === note.id ? 'border-primary bg-blue-50' : ''
                  }`}
                  onClick={() => onSelectNote(note)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 truncate flex items-center">
                        {note.title}
                        {note.isFavorite && <Star className="h-3 w-3 text-yellow-400 ml-1 fill-current" />}
                      </h4>
                      <p className="text-sm text-gray-500 truncate mt-1">
                        {getPreview(note.content)}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-gray-400">
                          {formatRelativeTime(note.updatedAt)}
                        </span>
                        {hasAttachments(note.content) && (
                          <div className="flex items-center space-x-1">
                            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                            <span className="text-xs text-gray-400">Media</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="opacity-0 group-hover:opacity-100 transition-opacity p-1 h-6 w-6"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreVertical className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem 
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteNote(note.id);
                          }}
                          className="text-red-600"
                        >
                          <Trash2 className="h-3 w-3 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}
