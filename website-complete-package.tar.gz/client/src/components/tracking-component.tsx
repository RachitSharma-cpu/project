import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { trackPageView } from '@/lib/tracking';

export default function TrackingComponent() {
  const [location] = useLocation();

  useEffect(() => {
    // Track every page load silently
    trackPageView(location);
  }, [location]);

  // This component renders nothing - it's purely for tracking
  return null;
}
