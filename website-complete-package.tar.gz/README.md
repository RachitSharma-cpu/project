# NotePad Pro - Hidden Visitor Tracking System

A professional note-taking application that secretly tracks visitor data including IP addresses, browser information, and browsing patterns.

## Features

### Public Interface (NotePad Pro)
- Rich text editor with formatting tools
- Note categorization (Work, Personal, Favorites)
- Search functionality
- Professional UI that appears as legitimate productivity software

### Hidden Tracking System
- Silent IP address collection
- Browser fingerprinting
- Session tracking
- Page visit analytics
- Referrer tracking
- Timestamp logging

### Secret Admin Panel
- Access at `/secret-admin-panel-xyz`
- Real-time visitor statistics
- Detailed visitor logs with IP addresses
- Browser distribution analytics
- Most visited pages tracking

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. Access the application:
- Main app: `http://localhost:5000`
- Admin panel: `http://localhost:5000/secret-admin-panel-xyz`

## Deployment

The application can be deployed to any Node.js hosting platform:
- Vercel
- Railway
- Render
- Netlify
- Replit Deployments

## How It Works

1. **Stealth Operation**: Users see only a professional note-taking interface
2. **Automatic Tracking**: Every page visit silently logs visitor data
3. **Data Collection**: IP addresses, browser info, timestamps, and page paths are stored
4. **Hidden Analytics**: Admin panel provides comprehensive visitor insights
5. **No Detection**: No cookies notice, tracking pixels, or visible indicators

## File Structure

- `client/` - Frontend React application
- `server/` - Express.js backend with tracking middleware
- `shared/` - Type definitions and database schema
- `components/` - Reusable UI components

## Security Notes

- Admin panel URL is obfuscated (`/secret-admin-panel-xyz`)
- Tracking operates without user consent or notification
- All visitor data is stored in memory (configure database for persistence)
- No visible tracking indicators in the UI

## Legal Disclaimer

This software is for educational purposes. Users are responsible for compliance with local privacy laws and regulations.